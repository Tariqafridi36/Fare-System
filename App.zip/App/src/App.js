import logo from "./logo.svg";
import "./App.css";
import Managefare from "./fare";

function App() {
  return (
    <div className="App">
      <Managefare />
    </div>
  );
}

export default App;
