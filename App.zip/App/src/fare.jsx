import React from "react";

const date = [
  { zone: 1, stations: [{ name: "Halborn" }, { name: "Earl" }], fare: 2.5 },
  { zone: 2, stations: [{ name: "Earl" }, { name: "Hammersmith" }], fare: 10 },
  { zone: 3, stations: [{ name: "Wimbeldon" }], fare: 2 },
];

let history = [];

const ManageZone = (props) => {
  for (let index = 0; index < props.stations.length; index++) {
    debugger;
    const element = props.stations[index];
    return <div>{element.name}</div>;
  }
};

const Managefare = () => {
  const [load, setLoad] = React.useState(0);
  const [start, setStart] = React.useState(false);
  const [totalFare, setTotalFare] = React.useState(0);
  const [journey, setJourney] = React.useState([]);
  const [startZone, setStartZone] = React.useState(0);

  const zone1calculation = (zone) => {
    setTotalFare(2.5);
    setLoad(load + totalFare - 2.5);
  };

  const outsiteZone1 = () => {
    setTotalFare(2);
    setLoad(load + totalFare - 2);
  };

  const includeZone1 = () => {
    setTotalFare(3);
    setLoad(load + totalFare - 3);
  };

  const excludeZone1 = () => {
    setTotalFare(2.25);
    setLoad(load + totalFare - 2.25);
  };

  const moreThen2Zone = () => {
    setTotalFare(3.3);
    setLoad(load + totalFare - 3.3);
  };

  const busJourney = () => {
    setTotalFare(1.7);
    setLoad(load + totalFare - 1.7);
  };

  const StartHandler = (zone, station) => {
    if (load === 0 || load < 5)
      alert("Not enough amount to continue journey, please reload your card");
    else {
      if (!start) {
        setStartZone(zone);
        setTotalFare(3.3);
        setLoad(load - 3.3);
      }

      setStart(!start);
      history.push({ name: zone });
      setJourney(history);

      if (start && startZone === 1 && zone === 1) {
        zone1calculation(zone);
      } else if (start && startZone === 1 && station === "Earl's Court") {
        zone1calculation(zone);
      } else if (start && zone === 2 && startZone === 2) {
        outsiteZone1();
      } else if (start && zone === 3 && startZone === 3) {
        outsiteZone1();
      } else if (start && (startZone === 1 || zone === 1)) {
        includeZone1();
      } else if (start && startZone === 2 && zone === 3) {
        excludeZone1();
      } else if (start && startZone === 3 && zone === 2) {
        excludeZone1();
      } else if (start && (startZone === 5 || zone === 5)) {
        moreThen2Zone();
      } else if (start && (startZone === 4 || zone === 4)) {
        busJourney();
      }
    }
  };

  return (
    <React.Fragment>
      <div style={{ display: "flex" }}>
        <div style={{ width: "40%", textAlign: "end" }}>
          <div className="stop">
            <p>Zone 1</p>
            <input
              type="button"
              value="Holborn"
              onClick={(e) => StartHandler(1, e.target.value)}
            ></input>
            <input
              type="button"
              value="Earl's Court"
              onClick={(e) => StartHandler(1, e.target.value)}
            ></input>
          </div>
          <div className="stop">
            <p>Zone 2</p>
            <input
              type="button"
              value="Hammersmith"
              onClick={(e) => StartHandler(2, e.target.value)}
            ></input>
            <input
              type="button"
              value="Earl's Court"
              onClick={(e) => StartHandler(2, e.target.value)}
            ></input>
          </div>
          <div className="stop">
            <p>Zone 3</p>
            <input
              type="button"
              value="Wimbeldon"
              onClick={(e) => StartHandler(3, e.target.value)}
            ></input>
            <input
              type="button"
              value="Station2"
              onClick={(e) => StartHandler(3, e.target.value)}
            ></input>
          </div>
          <div className="stop">
            <p>3 Zone Journey</p>
            <input
              type="button"
              value="Start"
              onClick={(e) => StartHandler(5, e.target.value)}
            ></input>
            <input
              type="button"
              value="Stop"
              onClick={(e) => StartHandler(5, e.target.value)}
            ></input>
          </div>
          <div className="stop">
            <p>Bus journey</p>
            <input
              type="button"
              value="Stop 1"
              onClick={(e) => StartHandler(4, e.target.value)}
            ></input>
            <input
              type="button"
              value="Stop 2"
              onClick={(e) => StartHandler(4, e.target.value)}
            ></input>
          </div>
        </div>
        <div style={{ width: "5%" }}></div>
        <div style={{ width: "40%", textAlign: "start" }}>
          <p>Current Balance: {load}</p>
          <input
            type="button"
            value="Load Card"
            className="btn btn-success"
            onClick={() => {
              setLoad(30);
            }}
          ></input>
          <input
            type="button"
            value="Reset"
            onClick={() => {
              setLoad(0);
              setStart(false);
              setTotalFare(0);
              history = [];
              setJourney([]);
            }}
          ></input>
          <div>
            <p>Fare Was : {totalFare}</p>
          </div>
          <div>
            <p>Visisted zone: {journey.map((item) => item.name)}</p>
          </div>
          <div>
            <p>Journey Status: {start ? "Journey  Started" : "Stopped"}</p>
          </div>
        </div>
      </div>
      {/* {date.map((row) => (
        <div>
          {row.zone}
          <ManageZone {...row} />


        </div>
      ))} */}
    </React.Fragment>
  );
};

export default Managefare;
